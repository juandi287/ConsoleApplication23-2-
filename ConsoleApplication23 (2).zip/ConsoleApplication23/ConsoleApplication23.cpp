#include "pch.h"
#include<iostream>
#include"Entidades.h"
using namespace std;
using namespace System;

int main()
{

    return 0;
}
